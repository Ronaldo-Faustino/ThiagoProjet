function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// --- VARIÁVEIS GLOBAIS DO JOGO ---
let estadoJogo = "inicial"; // "inicial", "nomeando", "explorando", "dialogando", "resolvendo_puzzle", "final"
let localAtual = "fazenda"; // "fazenda", "vila_rural", "estrada", "mercado_cidade", "prefeitura"

let meuPersonagem = { nome: "", energia: 100, inventario: [] }; // Objeto para o personagem principal

let historiaAtual = ""; // Texto principal da narrativa
let opcoesAtuais = [];  // Opções de escolha do jogador

let npcAtual = null;   // O NPC com quem o personagem está conversando
let dialogoAtual = 0; // Índice da linha de diálogo atual do NPC

let inputNome; // Elemento HTML para entrada do nome

// --- VARIÁVEIS PARA O PUZZLE ---
let puzzleItens = [];        // Itens disponíveis para o puzzle (ex: "Trigo", "Pão", "Leite", "Queijo")
let puzzleSlots = [];        // Slots onde os itens do puzzle devem ser colocados
let itemArrastandoPuzzle = null; // O item do puzzle que está sendo arrastado
let slotAtualHighlight = -1; // Índice do slot sendo destacado para drop

const CORES = {
  FUNDO_CAMPO: "#90EE90",     // Verde claro para campo
  FUNDO_CIDADE: "#A9A9A9",     // Cinza para a cidade
  FUNDO_CEU: "#87CEEB",       // Azul céu (tela inicial)
  FUNDO_GAME_OVER: "#FF6347", // Tomate (vermelho para game over)
  TEXTO_PADRAO: "#000000",    // Preto
  ITEM_CAMPO: "#228B22",      // Verde escuro para itens do campo
  ITEM_CIDADE: "#4169E1",     // Azul royal para itens da cidade
  BORDA_SELECIONADO: "#FFD700", // Amarelo dourado para item arrastado
  ELO_VAZIO: "#D3D3D3",       // Cinza claro para slots de puzzle vazios
  FUNDO_PUZZLE: "#B0E0E6"     // Azul claro para o fundo do puzzle
};

const PERSONAGENS = {
  fazendeiro: {
    nome: "Seu João",
    dialogos: [
      "Olá, [NOME_PERSONAGEM]! As coisas não andam bem... Os produtos do campo não chegam mais direito na cidade.",
      "Precisamos de mais estradas e menos burocracia para escoar nossa produção. Você pode ajudar?",
      "Procure a Dona Maria na Vila Rural, talvez ela tenha ideias de como melhorar o transporte."
    ]
  },
  donaMaria: {
    nome: "Dona Maria",
    dialogos: [
      "[NOME_PERSONAGEM], querido(a)! Que bom te ver. Os ônibus para a cidade estão em falta, ninguém consegue vir vender seus artesanatos.",
      "Talvez se você falasse com o Motorista Zeca no ponto de ônibus, ele saiba mais sobre o problema dos transportes."
    ]
  },
  motoristaZeca: {
    nome: "Motorista Zeca",
    dialogos: [
      "E aí, [NOME_PERSONAGEM]! Os ônibus estão parados porque faltam peças novas, a prefeitura não enviou a verba.",
      "Tente falar com a Prefeita no centro da cidade, ela precisa entender que o transporte é vital!"
    ]
  },
  prefeita: {
    nome: "Prefeita Ana",
    dialogos: [
      "Ah, [NOME_PERSONAGEM]! Sim, os orçamentos estão apertados. A cidade precisa de mais suprimentos do campo para justificar investimentos maiores.",
      "Se você conseguisse provar o valor dos produtos locais, talvez eu consiga realocar os fundos.",
      "Colete uma Cesta de Produtos Frescos no Mercado Central e me traga. Isso pode convencer o conselho."
    ]
  },
  vendedorMercado: {
    nome: "Vendedor Marcos",
    dialogos: [
      "Opa, [NOME_PERSONAGEM]! Produtos frescos? Aqui temos os melhores. Mas está difícil trazer tudo do campo sem as estradas em ordem.",
      "Para a Cesta de Produtos Frescos, preciso de um 'Fertilizante Orgânico' do campo para as minhas plantas. Troca justa?"
    ]
  }
};

const ITENS = {
  fertilizante: { nome: "Fertilizante Orgânico", descricao: "Um adubo natural, muito útil para plantas." },
  cestaProdutos: { nome: "Cesta de Produtos Frescos", descricao: "Uma variedade de frutas e vegetais do campo." },
  mapa: { nome: "Mapa Desbotado", descricao: "Um mapa antigo, talvez mostre atalhos." } // Exemplo, não usado na lógica atual
};

// Definição dos itens e slots para o puzzle
// A ordem dos nomes nos slots define a solução do puzzle
const PUZZLE_DEFINICAO = [
  { item: "TRIGO", tipo: "campo" },
  { item: "FARINHA", tipo: "cidade" },
  { item: "PÃO", tipo: "cidade" },

  { item: "LEITE FRESCO", tipo: "campo" },
  { item: "LATICÍNIO", tipo: "cidade" },
  { item: "QUEIJO", tipo: "cidade" },

  { item: "CAFÉ (GRÃO)", tipo: "campo" },
  { item: "CAFETERIA", tipo: "cidade" },
  { item: "CAFÉ SERVIDO", tipo: "cidade" }
];


// --- SETUP: Configuração Inicial do P5.js ---
function setup() {
  createCanvas(800, 600);
  textAlign(LEFT, TOP);
  textSize(20);
  noLoop(); // Não desenha continuamente, só quando há interação
  iniciarAventura(); // Inicia o jogo
}

// --- DRAW: O Loop Principal do Jogo ---
function draw() {
  background(240); // Fundo claro

  desenharCenario(); // Desenha o cenário de fundo

  fill(0); // Cor do texto
  textSize(20);

  // Exibe o texto principal (história ou diálogo)
  text(historiaAtual, 50, 50, width - 100, height - 200);

  // NOVO: Adiciona a chamada para desenhar o puzzle
  if (estadoJogo === "resolvendo_puzzle") {
    desenharPuzzle();
  } else if (estadoJogo !== "nomeando") { // Só exibe as opções se não estiver nomeando ou no puzzle
    textSize(18);
    let yOpcoes = height - 150;
    for (let i = 0; i < opcoesAtuais.length; i++) {
      let opcao = opcoesAtuais[i];
      fill(50, 100, 200); // Cor azul para as opções
      rect(50, yOpcoes + i * 40, width - 100, 30); // Botão retangular
      fill(255); // Texto branco
      text(opcao.texto, 60, yOpcoes + i * 40 + 5);
    }
  }

  // Desenha o HUD (Inventário e Energia)
  fill(0);
  textSize(16);
  if (meuPersonagem.nome && estadoJogo !== "nomeando" && estadoJogo !== "resolvendo_puzzle") { // Só mostra o HUD se o nome já foi escolhido e não está nomeando ou no puzzle
    text("Energia: " + meuPersonagem.energia, 50, 10);
    text("Local: " + localAtual.replace(/_/g, " ").toUpperCase(), width - 200, 10);
    text("Inventário: " + (meuPersonagem.inventario.length > 0 ? meuPersonagem.inventario.map(item => item.nome).join(", ") : "Vazio"), 50, height - 30);
  }
}

// --- FUNÇÕES DE LÓGICA DO JOGO ---

function iniciarAventura() {
  estadoJogo = "nomeando";
  historiaAtual = "Bem-vindo à Aventura da Conexão! Qual é o seu nome, herói?";
  opcoesAtuais = []; // Nenhuma opção de botão enquanto espera o nome

  meuPersonagem.nome = "";
  meuPersonagem.energia = 100;
  meuPersonagem.inventario = [];
  localAtual = "fazenda";

  // Reinicia variáveis do puzzle
  itemArrastandoPuzzle = null;
  slotAtualHighlight = -1;
  configurarPuzzle(); // Reiniciar o puzzle para um novo jogo

  // Cria o campo de texto para o nome
  if (inputNome) { // Remove o campo se ele já existir (para reinícios)
    inputNome.remove();
  }
  inputNome = createInput('');
  inputNome.position(width / 2 - 100, height / 2 + 50);
  inputNome.size(200, 30);
  inputNome.changed(definirNomePersonagem); // Chama a função quando o texto é confirmado (Enter)
  inputNome.show(); // Garante que o input esteja visível

  redraw();
}

function definirNomePersonagem() {
  let nomeDigitado = inputNome.value().trim(); // Pega o valor e remove espaços em branco
  if (nomeDigitado.length > 0) {
    meuPersonagem.nome = nomeDigitado.toUpperCase(); // Armazena o nome em maiúsculas
    inputNome.hide(); // Esconde o campo de entrada
    estadoJogo = "explorando"; // Muda o estado do jogo
    // Inicia a primeira cena da aventura
    historiaAtual = `Bem-vindo(a), ${meuPersonagem.nome}! Você percebe que uma estranha 'desconexão' está afastando o campo da cidade. Sua missão: restaurar essa harmonia. Sua jornada começa na Fazenda de seus avós.`;
    atualizarOpcoes(); // Carrega as primeiras opções de jogo
  } else {
    // Se o nome estiver vazio, pede para digitar novamente
    historiaAtual = "Por favor, digite um nome válido para o seu herói.";
  }
  redraw();
}

function desenharCenario() {
  // Cores de fundo baseadas no local
  if (localAtual.includes("fazenda") || localAtual.includes("rural")) {
    background(CORES.FUNDO_CAMPO); // Verde claro para campo
  } else if (localAtual.includes("cidade") || localAtual.includes("prefeitura") || localAtual.includes("mercado")) {
    background(CORES.FUNDO_CIDADE); // Cinza para cidade
  } else {
    background(CORES.FUNDO_CEU); // Azul para estrada/neutro
  }

  // Desenha elementos visuais simples (apenas para dar uma ideia)
  fill("#8B4513"); // Marrom
  if (localAtual === "fazenda") {
    rect(width / 2 - 50, height / 2 - 50, 100, 100); // Celeiro
    fill("#696969");
    triangle(width / 2 - 50, height / 2 - 50, width / 2 + 50, height / 2 - 50, width / 2, height / 2 - 100);
  } else if (localAtual === "vila_rural") {
    fill("#A0522D"); // Laranja escuro
    rect(width / 2 - 70, height / 2 - 60, 140, 120); // Casas
    fill("#808080");
    rect(width / 2 - 10, height - 80, 20, 70); // Ponto de ônibus
  } else if (localAtual === "mercado_cidade") {
    fill("#F5DEB3"); // Trigo
    rect(width / 2 - 150, height / 2 - 80, 300, 160); // Prédio do mercado
    fill("#FFD700");
    ellipse(width / 2, height / 2 + 30, 80, 80); // Um carrinho de compras simbólico
  } else if (localAtual === "prefeitura") {
    fill("#DCDCDC"); // Cinza claro
    rect(width / 2 - 120, height / 2 - 100, 240, 200); // Prédio grande
    fill("#B0C4DE");
    rect(width / 2 - 20, height / 2 + 50, 40, 50); // Porta
  }
}

function atualizarOpcoes() {
  opcoesAtuais = [];
  npcAtual = null; // Reseta o NPC ao mudar de opções

  switch (localAtual) {
    case "fazenda":
      historiaAtual = `Você está na Fazenda. O sol brilha, mas há uma sensação de preocupação no ar. Seu avô, o Seu João, está perto do celeiro.`;
      opcoesAtuais.push({ texto: "Conversar com Seu João", acao: "conversar", com: PERSONAGENS.fazendeiro });
      opcoesAtuais.push({ texto: "Ir para a Vila Rural", acao: "mudar_local", para: "vila_rural" });
      break;
    case "vila_rural":
      historiaAtual = `Você chegou à Vila Rural. Parece mais quieta do que o normal. Dona Maria está na praça.`;
      opcoesAtuais.push({ texto: "Conversar com Dona Maria", acao: "conversar", com: PERSONAGENS.donaMaria });
      opcoesAtuais.push({ texto: "Ir para a Estrada", acao: "mudar_local", para: "estrada" });
      opcoesAtuais.push({ texto: "Voltar para a Fazenda", acao: "mudar_local", para: "fazenda" });
      break;
    case "estrada":
      historiaAtual = `A Estrada é longa e solitária. Você vê um Motorista Zeca frustrado ao lado de seu ônibus quebrado.`;
      opcoesAtuais.push({ texto: "Conversar com Motorista Zeca", acao: "conversar", com: PERSONAGENS.motoristaZeca });
      opcoesAtuais.push({ texto: "Continuar para o Mercado da Cidade", acao: "mudar_local", para: "mercado_cidade" });
      opcoesAtuais.push({ texto: "Voltar para a Vila Rural", acao: "mudar_local", para: "vila_rural" });
      break;
    case "mercado_cidade":
      historiaAtual = `Você está no agitado Mercado Central da Cidade. Há muitos produtos, mas alguns espaços estão vazios. O Vendedor Marcos está em sua banca.`;
      opcoesAtuais.push({ texto: "Conversar com Vendedor Marcos", acao: "conversar", com: PERSONAGENS.vendedorMercado });
      opcoesAtuais.push({ texto: "Ir para a Prefeitura", acao: "mudar_local", para: "prefeitura" });
      opcoesAtuais.push({ texto: "Voltar para a Estrada", acao: "mudar_local", para: "estrada" });
      // Opção de coletar item se tiver o pré-requisito
      if (meuPersonagem.inventario.some(item => item.nome === ITENS.fertilizante.nome)) {
          opcoesAtuais.push({ texto: "Trocar Fertilizante por Cesta de Produtos Frescos", acao: "trocar_item" });
      }
      break;
    case "prefeitura":
      historiaAtual = `Você chegou à Prefeitura. É um prédio imponente, mas parece um pouco distante das necessidades reais. A Prefeita Ana está em seu gabinete.`;
      opcoesAtuais.push({ texto: "Conversar com a Prefeita Ana", acao: "conversar", com: PERSONAGENS.prefeita });
      opcoesAtuais.push({ texto: "Voltar para o Mercado da Cidade", acao: "mudar_local", para: "mercado_cidade" });
      // MUDANÇA AQUI: Inicia o puzzle em vez de entregar diretamente
      if (meuPersonagem.inventario.some(item => item.nome === ITENS.cestaProdutos.nome)) {
          opcoesAtuais.push({ texto: "Apresentar Conexões (Iniciar Puzzle)", acao: "iniciar_puzzle" });
      }
      break;
  }
  redraw();
}

function processarAcao(acaoEscolhida) {
  switch (acaoEscolhida.acao) {
    case "mudar_local":
      localAtual = acaoEscolhida.para;
      meuPersonagem.energia -= 5; // Custo de energia para mover
      if (meuPersonagem.energia <= 0) {
        fimDeJogo("Você ficou sem energia para continuar a jornada!");
        return;
      }
      atualizarOpcoes();
      break;
    case "conversar":
      npcAtual = acaoEscolhida.com;
      dialogoAtual = 0; // Começa do primeiro diálogo
      estadoJogo = "dialogando";
      exibirDialogo();
      break;
    case "dialogo_proximo":
      dialogoAtual++;
      if (dialogoAtual < npcAtual.dialogos.length) {
        exibirDialogo();
      } else {
        // Diálogo terminou
        estadoJogo = "explorando";
        // Lógicas específicas após diálogo (dar item, etc.)
        if (npcAtual === PERSONAGENS.fazendeiro && !meuPersonagem.inventario.some(item => item.nome === ITENS.fertilizante.nome)) {
          meuPersonagem.inventario.push(ITENS.fertilizante);
          historiaAtual = `Seu João te deu um ${ITENS.fertilizante.nome} de brinde! Parece útil.`;
        }
        atualizarOpcoes();
      }
      break;
    case "trocar_item":
      if (localAtual === "mercado_cidade" && meuPersonagem.inventario.some(item => item.nome === ITENS.fertilizante.nome)) {
        meuPersonagem.inventario = meuPersonagem.inventario.filter(item => item.nome !== ITENS.fertilizante.nome); // Remove fertilizante
        meuPersonagem.inventario.push(ITENS.cestaProdutos); // Adiciona cesta
        historiaAtual = `Você trocou o ${ITENS.fertilizante.nome} pela ${ITENS.cestaProdutos.nome}! Agora você tem algo para a Prefeita.`;
        atualizarOpcoes();
      } else {
        historiaAtual = "Você não tem o item certo para a troca!";
      }
      break;
    case "iniciar_puzzle":
      if (localAtual === "prefeitura" && meuPersonagem.inventario.some(item => item.nome === ITENS.cestaProdutos.nome)) {
        historiaAtual = "A Prefeita te desafia: 'Mostre-me a verdadeira conexão entre o Campo e a Cidade!' Organize os produtos para convencê-la.";
        estadoJogo = "resolvendo_puzzle";
        itemArrastandoPuzzle = null; // Garante que nenhum item está sendo arrastado ao iniciar
        reorganizarPuzzleItens(); // Embaralha os itens para o puzzle
        loop(); // Inicia o loop de desenho para o puzzle
      } else {
        historiaAtual = "Você ainda não tem a Cesta de Produtos Frescos para apresentar à Prefeita.";
      }
      break;

    case "entregar_missao": // Agora este será chamado APÓS o puzzle ser resolvido
      if (localAtual === "prefeitura" && meuPersonagem.inventario.some(item => item.nome === ITENS.cestaProdutos.nome)) {
        meuPersonagem.inventario = meuPersonagem.inventario.filter(item => item.nome !== ITENS.cestaProdutos.nome);
        fimDeJogo(`Parabéns, ${meuPersonagem.nome}! Você restaurou a Conexão entre o Campo e a Cidade! As estradas serão consertadas e os ônibus voltarão a circular. Você é um(a) herói(ina)!`);
      } else {
        historiaAtual = "Erro: Missão de entrega chamada sem os pré-requisitos.";
      }
      break;
  }
}

function exibirDialogo() {
  let dialogoFormatado = npcAtual.dialogos[dialogoAtual].replace("[NOME_PERSONAGEM]", meuPersonagem.nome);
  historiaAtual = npcAtual.nome + ": " + dialogoFormatado;
  opcoesAtuais = [{ texto: "Continuar...", acao: "dialogo_proximo" }];
  redraw();
}

function fimDeJogo(mensagem) {
  estadoJogo = "final";
  historiaAtual = "FIM DE JOGO! " + mensagem + "\n\nClique para reiniciar.";
  opcoesAtuais = []; // Nenhuma opção na tela final
  inputNome.hide(); // Garante que o input está escondido
  noLoop(); // Para o loop de desenho
  redraw();
}

// --- FUNÇÕES DO PUZZLE ---

function configurarPuzzle() {
  puzzleSlots = [];
  puzzleItens = [];

  // Cria os slots vazios para o puzzle (3 linhas de 3 slots para 3 sequências)
  let yOffset = height / 2 - 120; // Posição vertical inicial dos slots
  for (let i = 0; i < PUZZLE_DEFINICAO.length; i++) {
    // Calcula a posição dos slots em grade
    let x = (width / 2) - 130 + (i % 3) * (80 + 10); // 3 colunas
    let y = yOffset + floor(i / 3) * (40 + 20); // Novas linhas
    puzzleSlots.push({ x: x, y: y, item: null, nomeCorreto: PUZZLE_DEFINICAO[i].item }); // Armazena o item correto para comparação
  }

  // Adiciona os itens que o jogador deve arrastar
  let todosOsItensPuzzle = [];
  for (let def of PUZZLE_DEFINICAO) {
    todosOsItensPuzzle.push({
      nome: def.item,
      tipo: def.tipo,
      x: 0, y: 0, // Posição inicial será definida ao rearranjar
      originalX: 0, originalY: 0, // Para resetar se soltar errado
      noSlot: false // Indica se o item já está em um slot
    });
  }
  puzzleItens = shuffle(todosOsItensPuzzle); // Embaralha os itens

  // Define a posição inicial dos itens embaralhados na parte inferior da tela
  reorganizarPuzzleItens();
}

// Reorganiza os itens na parte inferior da tela para serem arrastados
function reorganizarPuzzleItens() {
  let startX = 50;
  let startY = height - 100;
  let currentX = startX;
  let currentY = startY;
  let itemWidth = 80;
  let itemHeight = 40;
  let padding = 10;

  for (let item of puzzleItens) {
    if (!item.noSlot) { // Só move os itens que não estão em slots
      item.x = currentX;
      item.y = currentY;
      item.originalX = currentX; // Guarda a posição original
      item.originalY = currentY;

      currentX += itemWidth + padding;
      if (currentX + itemWidth > width - 50) { // Nova linha se atingir a borda
        currentX = startX;
        currentY += itemHeight + padding;
      }
    }
  }
  redraw();
}


function desenharPuzzle() {
  background(CORES.FUNDO_PUZZLE); // Azul claro diferente para o fundo do puzzle

  // Desenha os slots
  for (let i = 0; i < puzzleSlots.length; i++) {
    let slot = puzzleSlots[i];
    
    // Define a cor base do slot (campo/cidade)
    if (PUZZLE_DEFINICAO[i].tipo === "campo") {
        fill(CORES.FUNDO_CAMPO); 
    } else {
        fill(CORES.FUNDO_CIDADE);
    }
    
    if (slotAtualHighlight === i) {
      stroke(CORES.BORDA_SELECIONADO); // Usa a cor de destaque
      strokeWeight(3);
    } else {
      noStroke();
    }
    rect(slot.x, slot.y, 80, 40, 5); // Slots retangulares

    if (slot.item) { // Se o slot tiver um item
      fill(slot.item.tipo === "campo" ? CORES.ITEM_CAMPO : CORES.ITEM_CIDADE);
      rect(slot.x, slot.y, 80, 40, 5);
      fill(255); // Texto branco
      textSize(14);
      text(slot.item.nome, slot.x + 40, slot.y + 20);
    } else {
      fill(CORES.TEXTO_PADRAO);
      textSize(12);
      text(slot.nomeCorreto, slot.x + 40, slot.y + 20); // Ajuda visual para o jogador
    }
  }

  // Desenha os itens para arrastar
  for (let item of puzzleItens) {
    if (itemArrastandoPuzzle === item) {
      strokeWeight(4);
      stroke(CORES.BORDA_SELECIONADO);
    } else {
      noStroke();
    }
    if (!item.noSlot || itemArrastandoPuzzle === item) { // Só desenha se não estiver no slot ou se estiver sendo arrastado
      fill(item.tipo === "campo" ? CORES.ITEM_CAMPO : CORES.ITEM_CIDADE);
      rect(item.x, item.y, 80, 40, 5);
      fill(255); // Texto branco
      textSize(14);
      text(item.nome, item.x + 40, item.y + 20);
    }
  }
  noStroke(); // Reseta o stroke

  // Instruções do puzzle
  fill(0);
  textSize(20);
  text("Conecte os itens do Campo e da Cidade nas sequências lógicas!", width / 2, 30);
  textSize(16);
  text("Arraste os itens de baixo para os espaços correspondentes.", width / 2, 60);
}

function verificarSolucaoPuzzle() {
  let puzzleCompleto = true;
  let puzzleCorreto = true;

  for (let i = 0; i < puzzleSlots.length; i++) {
    let slot = puzzleSlots[i];
    if (!slot.item) {
      puzzleCompleto = false; // Há slots vazios
      break;
    }
    if (slot.item.nome !== slot.nomeCorreto) {
      puzzleCorreto = false; // Um item está no lugar errado
    }
  }

  if (puzzleCompleto) {
    if (puzzleCorreto) {
      historiaAtual = `Excelente, ${meuPersonagem.nome}! A Prefeita Ana está impressionada com a sua demonstração da Conexão Campo & Cidade. Ela finalmente entende a importância!`;
      processarAcao({ acao: "entregar_missao" }); // Chama a ação de vitória
      noLoop(); // Para o loop de desenho quando o puzzle é resolvido
    } else {
      historiaAtual = "Hmm, a sequência não está perfeita. Tente novamente! Lembre-se da ordem lógica dos itens.";
      reiniciarPuzzle(); // Reinicia o puzzle para o jogador tentar de novo
      noLoop(); // Para o loop de desenho, ele será reiniciado em mousePressed
    }
  }
}

function reiniciarPuzzle() {
  // Retorna todos os itens para o pool arrastável
  for (let item of puzzleItens) {
    item.noSlot = false;
  }
  // Limpa os slots
  for (let slot of puzzleSlots) {
    slot.item = null;
  }
  itemArrastandoPuzzle = null;
  slotAtualHighlight = -1;
  puzzleItens = shuffle(puzzleItens); // Embaralha novamente para uma nova tentativa
  reorganizarPuzzleItens(); // Redesenha os itens embaralhados em suas posições iniciais
  redraw();
}

// Função auxiliar para embaralhar um array
function shuffle(array) {
  let currentIndex = array.length, randomIndex;
  while (currentIndex !== 0) {
    randomIndex = floor(random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
  }
  return array;
}


// --- EVENTOS DE MOUSE ---
function mousePressed() {
  if (estadoJogo === "final") {
    iniciarAventura(); // Reinicia o jogo
    return;
  }

  // Se estiver resolvendo o puzzle, tenta pegar um item para arrastar
  if (estadoJogo === "resolvendo_puzzle") {
    for (let i = 0; i < puzzleItens.length; i++) {
      let item = puzzleItens[i];
      // Verifica se o clique está dentro do item e ele não está em um slot
      if (!item.noSlot && mouseX > item.x && mouseX < item.x + 80 && mouseY > item.y && mouseY < item.y + 40) {
        itemArrastandoPuzzle = item;
        itemArrastandoPuzzle.offsetX = mouseX - item.x;
        itemArrastandoPuzzle.offsetY = mouseY - item.y;
        loop(); // Inicia o loop para arrastar (mouseDragged)
        return; // Sai da função para processar apenas o drag
      }
    }
  }

  // Se não estiver nomeando nem resolvendo puzzle, processa cliques nos botões de opção
  if (estadoJogo !== "nomeando" && estadoJogo !== "resolvendo_puzzle") {
    let yOpcoes = height - 150;
    for (let i = 0; i < opcoesAtuais.length; i++) {
      let opcao = opcoesAtuais[i];
      // Verifica se o clique está dentro da área do botão
      if (mouseX > 50 && mouseX < width - 50 &&
          mouseY > yOpcoes + i * 40 && mouseY < yOpcoes + i * 40 + 30) {
        processarAcao(opcao);
        break; // Processa apenas uma opção por clique
      }
    }
  }
}

function mouseReleased() {
  if (estadoJogo === "resolvendo_puzzle" && itemArrastandoPuzzle) {
    let itemFoiSolto = false;

    for (let i = 0; i < puzzleSlots.length; i++) {
      let slot = puzzleSlots[i];
      // Verifica se o item foi solto sobre um slot vazio
      if (mouseX > slot.x && mouseX < slot.x + 80 &&
          mouseY > slot.y && mouseY < slot.y + 40 &&
          !slot.item) { // O slot deve estar vazio
        slot.item = itemArrastandoPuzzle; // Coloca o item no slot
        itemArrastandoPuzzle.x = slot.x; // Ajusta a posição do item para o slot
        itemArrastandoPuzzle.y = slot.y;
        itemArrastandoPuzzle.noSlot = true; // Marca que o item está em um slot
        itemFoiSolto = true;
        break;
      }
    }

    if (!itemFoiSolto) {
      // Se não foi solto em um slot válido, retorna para a posição original (se houver)
      itemArrastandoPuzzle.x = itemArrastandoPuzzle.originalX;
      itemArrastandoPuzzle.y = itemArrastandoPuzzle.originalY;
      itemArrastandoPuzzle.noSlot = false;
    }

    itemArrastandoPuzzle = null; // Libera o item
    slotAtualHighlight = -1; // Remove highlight

    // Verifica a solução do puzzle após cada movimento
    verificarSolucaoPuzzle();
    noLoop(); // Para o loop, para economizar recursos (será ativado novamente se arrastar)
  }
}

function mouseDragged() {
  if (estadoJogo === "resolvendo_puzzle" && itemArrastandoPuzzle) {
    itemArrastandoPuzzle.x = mouseX - itemArrastandoPuzzle.offsetX;
    itemArrastandoPuzzle.y = mouseY - itemArrastandoPuzzle.offsetY;

    // Atualiza o highlight do slot
    slotAtualHighlight = -1;
    for (let i = 0; i < puzzleSlots.length; i++) {
      let slot = puzzleSlots[i];
      if (mouseX > slot.x && mouseX < slot.x + 80 &&
          mouseY > slot.y && mouseY < slot.y + 40 &&
          !slot.item) {
        slotAtualHighlight = i;
        break;
      }
    }
  }
}